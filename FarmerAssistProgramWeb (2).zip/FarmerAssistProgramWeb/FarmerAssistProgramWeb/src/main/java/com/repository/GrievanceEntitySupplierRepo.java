package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.entity.GrievanceEntitySupplier;

public interface GrievanceEntitySupplierRepo extends JpaRepository<GrievanceEntitySupplier, Long> {

}
